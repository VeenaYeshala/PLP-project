package com.cg.hbms.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.hbms.exception.HBMSException;

public class DbUtil {
	public static Connection getConnection() throws HBMSException
	{
		
		try {
			InitialContext context=new InitialContext();
			DataSource ds=(DataSource) context.lookup("java:/jdbc/OracleDS");
			return ds.getConnection();
		} catch (SQLException e) {
			throw new HBMSException(e.getMessage());
		} catch (NamingException e) {
			throw new HBMSException(e.getMessage());
		}
		
	}
}
