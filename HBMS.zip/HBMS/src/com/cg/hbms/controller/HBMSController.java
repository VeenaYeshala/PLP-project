package com.cg.hbms.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.cg.hbms.dto.BookingDetails;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.RoomDetails;
import com.cg.hbms.dto.UserBean;
import com.cg.hbms.dto.Users;
import com.cg.hbms.exception.HBMSException;
import com.cg.hbms.service.HBMSService;
import com.cg.hbms.service.HBMSServiceImpl;

@WebServlet("*.do")
public class HBMSController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	HBMSService hbmsService=new HBMSServiceImpl();
	RequestDispatcher dispatcher=null;
   
    public HBMSController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String urlPattern=request.getServletPath();
		switch (urlPattern) {
		case "/displayHomePage.do":
			response.sendRedirect("home.jsp");			
			break;
		
		case "/customer.do":
			String crole=request.getParameter("role");
			request.getSession().setAttribute("role", crole);
			response.sendRedirect("login.jsp");
			break;
		
		case "/employee.do":
			String erole=request.getParameter("role");
			request.getSession().setAttribute("role", erole);
			response.sendRedirect("login.jsp");
			break;
		
		case "/register.do":
			dispatcher=request.getRequestDispatcher("register.jsp");
			dispatcher.forward(request, response);
			
			break;
		
		case "/addInDb.do":
			Users users=new Users();
			try {
				users.setUserName(request.getParameter("user_name"));
				users.setPassword(request.getParameter("password"));
				users.setMobileNo(request.getParameter("mobile_no"));
				users.setAddress(request.getParameter("address"));
				users.setEmail(request.getParameter("email"));
				users.setPhone(request.getParameter("phone"));
				String role = (String) request.getSession().getAttribute("role");
				users.setRole(role);
			
				int result=hbmsService.registerUsers(users);
				if(result==1) {
					dispatcher=request.getRequestDispatcher("login.jsp");
					dispatcher.forward(request, response);
				}
			} catch (HBMSException e) {
				dispatcher = request.getRequestDispatcher("error.jsp");
				request.setAttribute("exception", e);
				dispatcher.forward(request, response);
			}
			break;
		
		
		case "/search.do":
			String userName=request.getParameter("userName");
			String password=request.getParameter("password");
			//request.getSession().setAttribute("userName", userName);
			UserBean uBean=new UserBean(userName, password);
			Users user=new Users();
			try {
				
				boolean result = hbmsService.validateLogin(uBean);
				request.getSession().setAttribute("userLogin", uBean);
				int userId=hbmsService.getUserId(userName);
				request.getSession().setAttribute("userId", userId);
				if(result){
					
					
					dispatcher = request.getRequestDispatcher("search.jsp");
					request.getSession().setAttribute("userName", userName);
					dispatcher.forward(request, response);
				}
				
				else{
					String message="User name or password incorrect";
					request.getSession().setAttribute("message", message);
					dispatcher = request.getRequestDispatcher("login.jsp");
					request.getSession().removeAttribute("userName");
					dispatcher.forward(request, response);
					
				}
				
			} catch (HBMSException e) {
				dispatcher = request.getRequestDispatcher("error.jsp");
				request.setAttribute("exception", e);
				dispatcher.forward(request, response);
			}
			break;
		
		case "/searchPage.do":
			dispatcher = request.getRequestDispatcher("search.jsp");
			request.getSession().getAttribute("userLogin");
			dispatcher.forward(request, response);
			break;
			
		case "/location.do":
			String location=request.getParameter("search");
			
			String loc=location.toUpperCase();
			request.getSession().setAttribute("city", loc);
			try {
				List<Hotels> hotels= hbmsService.getHotels(loc);
				dispatcher=request.getRequestDispatcher("listofhotels.jsp");
				request.setAttribute("hotellist", hotels);
				dispatcher.forward(request, response);
			} catch (HBMSException e) {
				dispatcher = request.getRequestDispatcher("error.jsp");
				request.setAttribute("exception", e);
				dispatcher.forward(request, response);
			}
			break;
		
		case "/roomdetails.do":
			int hotelId= Integer.parseInt(request.getParameter("hotelId"));
			
			try {
				String hotelName=hbmsService.getHotelname(hotelId);
				request.getSession().setAttribute("hotelName", hotelName);
				List<RoomDetails> rooms=hbmsService.getRooms(hotelId);
				
				request.setAttribute("roomlist", rooms);
				dispatcher=request.getRequestDispatcher("listofrooms.jsp");
				
				dispatcher.forward(request, response);
			} catch (HBMSException e) {
				dispatcher = request.getRequestDispatcher("error.jsp");
				request.setAttribute("exception", e);
				dispatcher.forward(request, response);
			}
			break;
		
		case "/bookNow.do":
			String price=request.getParameter("rate");
			float rate = Float.parseFloat(price);
			request.getSession().setAttribute("price", rate);
			int hotel_Id=Integer.parseInt(request.getParameter("hotelId"));
			request.getSession().setAttribute("hotelId", hotel_Id);
			String roomId=request.getParameter("roomId");
			request.getSession().setAttribute("roomId", roomId);
			
			int user_id=(int) request.getSession().getAttribute("userId");
			LocalDate localdate=LocalDate.now();
			request.getSession().setAttribute("localdate", localdate);
			dispatcher=request.getRequestDispatcher("hoteldetails.jsp");
			dispatcher.forward(request, response);
			break;
		
		case "/addBookingDetails.do":
			BookingDetails bookingDetails = new BookingDetails();
			
			try {
				
				
				String room=(String) request.getSession().getAttribute("roomId");
				bookingDetails.setRoomId(room);
				
				int userid=(int) request.getSession().getAttribute("userId");
				bookingDetails.setUserId(userid);
				String datefrom= request.getParameter("datefrom");
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDate from=LocalDate.parse(datefrom, formatter);
				bookingDetails.setBookedFrom(from);
				
				String dateto=request.getParameter("dateto");
				LocalDate to=LocalDate.parse(dateto, formatter);
				
				bookingDetails.setBookedTo(to);
				int adults=Integer.parseInt(request.getParameter("Adult"));
				bookingDetails.setNoOfAdults(adults);
				int child=Integer.parseInt(request.getParameter("Child"));
				bookingDetails.setNoOfChildren(child);
				
				long daysBetween = ChronoUnit.DAYS.between(from, to);
				float perdayprice=(float) request.getSession().getAttribute("price");
				
				int p=(adults*200)+(child*100);
				float perday=perdayprice+p;
				float total=perday*daysBetween;
				bookingDetails.setAmount(total);
				
				
				int result1=hbmsService.addBookingDetails(bookingDetails);
				
				int res=hbmsService.updateAvailability(room);
				int bookingId=hbmsService.getBookingId(room);
				request.getSession().setAttribute("bookingId", bookingId);
				if(result1==1) {
					dispatcher=request.getRequestDispatcher("success.jsp");
					request.getSession().setAttribute("bookingDetails", bookingDetails);
					dispatcher.forward(request, response);
				}
			} catch (HBMSException e) {
				dispatcher = request.getRequestDispatcher("error.jsp");
				request.setAttribute("exception", e);
				dispatcher.forward(request, response);
			}
			break;
		case "/contact.do":
			response.sendRedirect("contact.jsp");	
			break;
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
