package com.cg.hbms.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.hbms.dao.HBMSDao;
import com.cg.hbms.dao.HBMSDaoImpl;
import com.cg.hbms.dto.Hotels;
import com.cg.hbms.dto.UserBean;
import com.cg.hbms.dto.Users;
import com.cg.hbms.exception.HBMSException;

public class HBMSTest {
	
	HBMSDao hbmsDao;
	Users users;
	Hotels hotels;
	UserBean uBean;
	
	@Before
	public void init() {
		hbmsDao=new HBMSDaoImpl();
		users = new Users();
		hotels = new Hotels();
	}
	
	@Ignore
	@Test
	public void testRegisterUsers() {
		//fail("Not yet implemented");
	}
	
	@Test
	public void testValidateLogin() {
		try {
			uBean = new UserBean("Veena", "veena");
			assertNotNull(hbmsDao.validateLogin(uBean));
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetHotels() {
		try {
			assertNotNull(hbmsDao.getHotels("HYDERABAD"));
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetRooms() {
		try {
			assertNotNull(hbmsDao.getRooms(101));
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Ignore
	@Test
	public void testUpdateAvailability() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testGetUserId() {
		try {
			assertNotNull(hbmsDao.getUserId("Veena"));
		} catch (HBMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Ignore
	@Test
	public void testAddBookingDetails() {
		fail("Not yet implemented");
	}
	
	@Ignore
	@Test
	public void testGetBookingId() {
		fail("Not yet implemented");
	}

}
