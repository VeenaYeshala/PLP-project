package com.cg.hbms.exception;

public class HBMSException extends Exception{
	
	public HBMSException() {
		super();
	}
	
	public HBMSException(String message) {
		super(message);
	}

}
